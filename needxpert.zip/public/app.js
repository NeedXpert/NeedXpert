// NeedXpert Client Application State & Handlers
let allExperts = [];
let activeCategory = 'All';
let searchQuery = '';
let sortBy = 'rating';
let selectedExpertForBooking = null;
let currentGateway = 'phonepe';
let activeTrackedBooking = null;

// Comprehensive State and District Data for India
const INDIA_STATES_DISTRICTS = {
  "Andhra Pradesh": ["Ananthapuramu", "Anakapalli", "Bapatla", "Chittoor", "East Godavari (Rajahmundry)", "Eluru", "Guntur", "Kakinada", "Konaseema", "Krishna (Machilipatnam)", "Kurnool", "Nandyal", "NTR (Vijayawada)", "Palnadu", "Prakasam (Ongole)", "Nellore", "Srikakulam", "Tirupati", "Visakhapatnam", "Vizianagaram", "West Godavari (Bhimavaram)", "YSR Kadapa", "Other (Custom)"],
  "Assam": ["Baksa", "Barpeta", "Bongaigaon", "Cachar (Silchar)", "Charaideo", "Darrang", "Dhemaji", "Dhubri", "Dibrugarh", "Goalpara", "Golaghat", "Guwahati / Kamrup Metro", "Kamrup Rural", "Jorhat", "Karbi Anglong", "Karimganj", "Kokrajhar", "Lakhimpur", "Majuli", "Morigaon", "Nagaon", "Nalbari", "Sivasagar", "Sonitpur (Tezpur)", "Tinsukia", "Other (Custom)"],
  "Bihar": ["Araria", "Arwal", "Aurangabad", "Banka", "Begusarai", "Bhagalpur", "Bhojpur (Arrah)", "Buxar", "Darbhanga", "East Champaran (Motihari)", "Gaya", "Gopalganj", "Jamui", "Jehanabad", "Kaimur (Bhabua)", "Katihar", "Khagaria", "Kishanganj", "Lakhisarai", "Madhepura", "Madhubani", "Munger", "Muzaffarpur", "Nalanda (Bihar Sharif)", "Nawada", "Patna", "Purnia", "Rohtas (Sasaram)", "Saharsa", "Samastipur", "Saran (Chapra)", "Sheikhpura", "Sheohar", "Sitamarhi", "Siwan", "Supaul", "Vaishali (Hajipur)", "West Champaran (Bettiah)", "Other (Custom)"],
  "Chandigarh": ["Chandigarh"],
  "Chhattisgarh": ["Balod", "Baloda Bazar", "Bastar (Jagdalpur)", "Bemetara", "Bilaspur", "Dhamtari", "Durg / Bhilai", "Janjgir-Champa", "Korba", "Koriya", "Mahasamund", "Raigarh", "Raipur", "Rajnandgaon", "Surguja (Ambikapur)", "Other (Custom)"],
  "Delhi (NCT)": ["Central Delhi", "East Delhi", "New Delhi", "North Delhi", "North East Delhi", "North West Delhi", "Shahdara", "South Delhi", "South East Delhi", "South West Delhi", "West Delhi", "Other (Custom)"],
  "Goa": ["North Goa (Panaji / Mapusa)", "South Goa (Margao / Vasco)", "Other (Custom)"],
  "Gujarat": ["Ahmedabad", "Amreli", "Anand", "Aravalli", "Banaskantha (Palanpur)", "Bharuch", "Bhavnagar", "Botad", "Chhota Udaipur", "Dahod", "Dang", "Devbhoomi Dwarka", "Gandhinagar", "Gir Somnath (Veraval)", "Jamnagar", "Junagadh", "Kheda (Nadiad)", "Kutch (Bhuj)", "Mahisagar", "Mehsana", "Morbi", "Narmada", "Navsari", "Panchmahal (Godhra)", "Patan", "Porbandar", "Rajkot", "Sabarkantha (Himmatnagar)", "Surat", "Surendranagar", "Tapi", "Vadodara", "Valsad", "Other (Custom)"],
  "Haryana": ["Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad", "Gurugram (Gurgaon)", "Hisar", "Jhajjar (Bahadurgarh)", "Jind", "Kaithal", "Karnal", "Kurukshetra", "Mahendragarh (Narnaul)", "Nuh", "Palwal", "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa", "Sonipat", "Yamunanagar", "Other (Custom)"],
  "Himachal Pradesh": ["Bilaspur", "Chamba", "Hamirpur", "Kangra (Dharamshala)", "Kinnaur", "Kullu / Manali", "Lahaul and Spiti", "Mandi", "Shimla", "Sirmaur (Nahan)", "Solan (Baddi)", "Una", "Other (Custom)"],
  "Jammu & Kashmir": ["Anantnag", "Bandipora", "Baramulla", "Budgam", "Doda", "Ganderbal", "Jammu", "Kathua", "Kishtwar", "Kulgam", "Kupwara", "Poonch", "Pulwama", "Rajouri", "Ramban", "Reasi", "Samba", "Shopian", "Srinagar", "Udhampur", "Other (Custom)"],
  "Jharkhand": ["Bokaro", "Chatra", "Deoghar", "Dhanbad", "Dumka", "East Singhbhum (Jamshedpur)", "Garhwa", "Giridih", "Godda", "Gumla", "Hazaribagh", "Jamtara", "Khunti", "Koderma", "Latehar", "Lohardaga", "Pakur", "Palamu (Daltonganj)", "Ramgarh", "Ranchi", "Sahibganj", "Seraikela Kharsawan", "Simdega", "West Singhbhum (Chaibasa)", "Other (Custom)"],
  "Karnataka": ["Bagalkote", "Ballari", "Belagavi (Belgaum)", "Bengaluru Urban", "Bengaluru Rural", "Bidar", "Chamarajanagara", "Chikkaballapura", "Chikkamagaluru", "Chitradurga", "Dakshina Kannada (Mangaluru)", "Davanagere", "Dharwad (Hubballi)", "Gadag", "Hassan", "Haveri", "Kalaburagi (Gulbarga)", "Kodagu (Madikeri)", "Kolar", "Koppal", "Mandya", "Mysuru (Mysore)", "Raichur", "Ramanagara", "Shivamogga (Shimoga)", "Tumakuru", "Udupi", "Uttara Kannada (Karwar)", "Vijayapura (Bijapur)", "Yadgir", "Other (Custom)"],
  "Kerala": ["Alappuzha", "Ernakulam (Kochi)", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam", "Kozhikode (Calicut)", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram (Trivandrum)", "Thrissur", "Wayanad", "Other (Custom)"],
  "Madhya Pradesh": ["Agar Malwa", "Alirajpur", "Anuppur", "Ashoknagar", "Balaghat", "Barwani", "Betul", "Bhind", "Bhopal", "Burhanpur", "Chhatarpur", "Chhindwara", "Damoh", "Datia", "Dewas", "Dhar", "Dindori", "Guna", "Gwalior", "Harda", "Hoshangabad (Narmadapuram)", "Indore", "Jabalpur", "Jhabua", "Katni", "Khandwa", "Khargone", "Mandla", "Mandsaur", "Morena", "Narsinghpur", "Neemuch", "Panna", "Raisen", "Rajgarh", "Ratlam", "Rewa", "Sagar", "Satna", "Sehore", "Seoni", "Shahdol", "Shajapur", "Sheopur", "Shivpuri", "Sidhi", "Singrauli", "Tikamgarh", "Ujjain", "Umaria", "Vidisha", "Other (Custom)"],
  "Maharashtra": ["Ahmednagar", "Akola", "Amravati", "Aurangabad (Chhatrapati Sambhaji Nagar)", "Beed", "Bhandara", "Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kolhapur", "Latur", "Mumbai City", "Mumbai Suburban (Andheri/Bandra/Borivali)", "Nagpur", "Nanded", "Nandurbar", "Nashik", "Navi Mumbai", "Osmanabad (Dharashiv)", "Palghar", "Parbhani", "Pune (PCMC/Hinjawadi)", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal", "Other (Custom)"],
  "Odisha": ["Angul", "Balangir", "Balasore (Baleswar)", "Bargarh", "Bhadrak", "Boudh", "Cuttack", "Deogarh", "Dhenkanal", "Gajapati", "Ganjam (Berhampur)", "Jagatsinghpur", "Jajpur", "Jharsuguda", "Kalahandi", "Kandhamal", "Kendrapara", "Kendujhar (Keonjhar)", "Khordha (Bhubaneswar)", "Koraput", "Malkangiri", "Mayurbhanj (Baripada)", "Nabarangpur", "Nayagarh", "Nuapada", "Puri", "Rayagada", "Sambalpur", "Subarnapur (Sonepur)", "Sundargarh (Rourkela)", "Other (Custom)"],
  "Punjab": ["Amritsar", "Barnala", "Bathinda", "Faridkot", "Fatehgarh Sahib", "Fazilka", "Ferozepur", "Gurdaspur", "Hoshiarpur", "Jalandhar", "Kapurthala", "Ludhiana", "Mansa", "Moga", "Mohali (SAS Nagar)", "Muktsar", "Pathankot", "Patiala", "Rupnagar (Ropar)", "Sangrur", "Tarn Taran", "Other (Custom)"],
  "Rajasthan": ["Ajmer", "Alwar", "Banswara", "Baran", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur", "Hanumangarh", "Jaipur", "Jaisalmer", "Jalore", "Jhalawar", "Jhunjhunu", "Jodhpur", "Karauli", "Kota", "Nagaur", "Pali", "Pratapgarh", "Rajsamand", "Sawai Madhopur", "Sikar", "Sirohi", "Sri Ganganagar", "Tonk", "Udaipur", "Other (Custom)"],
  "Tamil Nadu": ["Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode", "Kallakurichi", "Kanchipuram", "Kanyakumari (Nagercoil)", "Karur", "Krishnagiri", "Madurai", "Mayiladuthurai", "Nagapattinam", "Namakkal", "Nilgiris (Ooty)", "Perambalur", "Pudukkottai", "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi", "Thanjavur", "Theni", "Thoothukudi (Tuticorin)", "Tiruchirappalli (Trichy)", "Tirunelveli", "Tirupathur", "Tiruppur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar", "Other (Custom)"],
  "Telangana": ["Adilabad", "Bhadradri Kothagudem", "Hyderabad (Central/Hitec City)", "Jagtial", "Jangaon", "Jayashankar Bhupalpally", "Jogulamba Gadwal", "Kamareddy", "Karimnagar", "Khammam", "Kumuram Bheem Asifabad", "Mahabubabad", "Mahabubnagar", "Mancherial", "Medak", "Medchal-Malkajgiri", "Mulugu", "Nagarkurnool", "Nalgonda", "Narayanpet", "Nirmal", "Nizamabad", "Peddapalli (Ramagundam)", "Rajanna Sircilla", "Rangareddy (Gachibowli/Shamshabad)", "Sangareddy", "Siddipet", "Suryapet", "Vikarabad", "Wanaparthy", "Warangal", "Hanamkonda", "Yadadri Bhuvanagiri", "Other (Custom)"],
  "Uttar Pradesh": ["Agra", "Aligarh", "Ambedkar Nagar", "Amethi", "Amroha", "Auraiya", "Ayodhya (Faizabad)", "Azamgarh", "Baghpat", "Bahraich", "Ballia", "Balrampur", "Banda", "Barabanki", "Bareilly", "Basti", "Bhadohi", "Bijnor", "Budaun", "Bulandshahr", "Chandauli", "Chitrakoot", "Deoria", "Etah", "Etawah", "Farrukhabad", "Fatehpur", "Firozabad", "Gautam Buddha Nagar (Noida/Greater Noida)", "Ghaziabad", "Ghazipur", "Gonda", "Gorakhpur", "Hamirpur", "Hapur", "Hardoi", "Hathras", "Jalaun (Orai)", "Jaunpur", "Jhansi", "Kannauj", "Kanpur Dehat", "Kanpur Nagar", "Kasganj", "Kaushambi", "Kheri (Lakhimpur)", "Kushinagar", "Lalitpur", "Lucknow", "Maharajganj", "Mahoba", "Mainpuri", "Mathura", "Mau", "Meerut", "Mirzapur", "Moradabad", "Muzaffarnagar", "Pilibhit", "Pratapgarh", "Prayagraj (Allahabad)", "Raebareli", "Rampur", "Saharanpur", "Sambhal", "Sant Kabir Nagar", "Shahjahanpur", "Shamli", "Shravasti", "Siddharthnagar", "Sitapur", "Sonbhadra", "Sultanpur", "Unnao", "Varanasi", "Other (Custom)"],
  "Uttarakhand": ["Almora", "Bageshwar", "Chamoli", "Champawat", "Dehradun (Rishikesh)", "Haridwar (Roorkee)", "Nainital (Haldwani)", "Pauri Garhwal", "Pithoragarh", "Rudraprayag", "Tehri Garhwal", "Udham Singh Nagar (Rudrapur/Kashipur)", "Uttarkashi", "Other (Custom)"],
  "West Bengal": ["Alipurduar", "Bankura", "Birbhum (Bolpur/Suri)", "Cooch Behar", "Dakshin Dinajpur (Balurghat)", "Darjeeling / Siliguri", "Hooghly (Serampore/Chinsurah)", "Howrah", "Jalpaiguri", "Jhargram", "Kalimpong", "Kolkata (Central/Salt Lake/New Town)", "Malda", "Murshidabad (Berhampore)", "Nadia (Kalyani/Krishnanagar)", "North 24 Parganas (Barasat/Rajarhat)", "Paschim Bardhaman (Asansol/Durgapur)", "Paschim Medinipur (Kharagpur)", "Purba Bardhaman", "Purba Medinipur (Haldia/Digha)", "Purulia", "South 24 Parganas", "Uttar Dinajpur (Raiganj)", "Other (Custom)"]
};

// Dynamic helper handlers for state and district changes
function onBookingStateChange(stateName) {
  const districtSelect = document.getElementById('book-district');
  const customDistrictInput = document.getElementById('book-district-custom');
  if (!districtSelect) return;

  if (!stateName || !INDIA_STATES_DISTRICTS[stateName]) {
    districtSelect.innerHTML = '<option value="">-- Select State First --</option>';
    districtSelect.disabled = true;
    if (customDistrictInput) customDistrictInput.style.display = 'none';
    return;
  }

  const districts = INDIA_STATES_DISTRICTS[stateName];
  districtSelect.disabled = false;
  districtSelect.innerHTML = `
    <option value="">-- Select District / City in ${stateName} --</option>
    ${districts.map(d => `<option value="${d}">${d}</option>`).join('')}
  `;

  if (customDistrictInput) {
    customDistrictInput.style.display = 'none';
    customDistrictInput.value = '';
  }
}

function onBookingDistrictChange(districtName) {
  const customDistrictInput = document.getElementById('book-district-custom');
  if (!customDistrictInput) return;

  if (districtName === 'Other (Custom)') {
    customDistrictInput.style.display = 'block';
    customDistrictInput.required = true;
    customDistrictInput.focus();
  } else {
    customDistrictInput.style.display = 'none';
    customDistrictInput.required = false;
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  loadCategories();
  loadExperts();
  setupEventListeners();
  checkForUrlBooking();
});

function checkForUrlBooking() {
  const urlParams = new URLSearchParams(window.location.search);
  const trackId = urlParams.get('track');
  if (trackId) {
    const trackerInput = document.getElementById('tracker-search-input');
    if (trackerInput) trackerInput.value = trackId;
    trackService(trackId);
    const trackerSec = document.getElementById('tracker');
    if (trackerSec) trackerSec.scrollIntoView({ behavior: 'smooth' });
  }
}

// ── CATEGORIES ──
async function loadCategories() {
  try {
    const res = await fetch('/api/categories');
    const data = await res.json();
    if (data.success && data.categories) {
      renderCategories(data.categories);
      renderCategoryFilterPills(data.categories);
      populateCategoryDropdowns(data.categories);
    }
  } catch (e) {
    console.error('Failed to load categories', e);
  }
}

function renderCategories(categories) {
  const grid = document.getElementById('categories-grid');
  if (!grid) return;
  grid.innerHTML = categories.map(cat => `
    <div class="cat-card" onclick="filterByCategory('${cat.name}')" id="cat-card-${cat.name.replace(/[^a-zA-Z0-9]/g, '')}">
      <div class="cat-icon-wrap">${cat.icon}</div>
      <div class="cat-name">${cat.name}</div>
      <div class="cat-count">${cat.count} expert${cat.count === 1 ? '' : 's'} ready</div>
      <p style="font-size:0.78rem;color:var(--gray-400);margin-top:6px;position:relative;line-height:1.4">${cat.description || ''}</p>
    </div>
  `).join('');
}

function renderCategoryFilterPills(categories) {
  const filterWrap = document.getElementById('expert-category-pills');
  if (!filterWrap) return;
  const allPill = `<button class="filter-pill ${activeCategory === 'All' ? 'active' : ''}" onclick="filterByCategory('All')" id="pill-all">All Categories</button>`;
  const catPills = categories.map(cat => `
    <button class="filter-pill ${activeCategory === cat.name ? 'active' : ''}" onclick="filterByCategory('${cat.name}')" id="pill-${cat.name.replace(/[^a-zA-Z0-9]/g, '')}">
      ${cat.icon} ${cat.name} <span class="pill-badge">${cat.count}</span>
    </button>
  `).join('');
  filterWrap.innerHTML = allPill + catPills;
}

function populateCategoryDropdowns(categories) {
  const selects = document.querySelectorAll('.category-dropdown');
  selects.forEach(select => {
    const current = select.value;
    select.innerHTML = categories.map(c => `<option value="${c.name}">${c.icon} ${c.name}</option>`).join('');
    if (current) select.value = current;
  });
}

function filterByCategory(categoryName) {
  activeCategory = categoryName;
  document.querySelectorAll('.filter-pill').forEach(pill => pill.classList.remove('active'));
  const activePill = document.getElementById(`pill-${categoryName.replace(/[^a-zA-Z0-9]/g, '')}`) || document.getElementById('pill-all');
  if (activePill) activePill.classList.add('active');

  const expSection = document.getElementById('experts');
  if (expSection) {
    expSection.scrollIntoView({ behavior: 'smooth' });
  }
  loadExperts();
}

// ── EXPERTS ──
async function loadExperts() {
  const grid = document.getElementById('experts-grid');
  if (grid) {
    grid.innerHTML = `<div style="grid-column: 1/-1; text-align:center; padding: 40px; color: rgba(255,255,255,0.7);"><div class="spinner"></div><p style="margin-top:12px">Loading verified experts...</p></div>`;
  }
  try {
    let url = `/api/experts?sort=${sortBy}`;
    if (activeCategory && activeCategory !== 'All') {
      url += `&category=${encodeURIComponent(activeCategory)}`;
    }
    if (searchQuery) {
      url += `&search=${encodeURIComponent(searchQuery)}`;
    }

    const res = await fetch(url);
    const data = await res.json();
    if (data.success) {
      allExperts = data.experts;
      renderExperts(data.experts);
      updateCategoryCountTitle(data.experts.length);
    }
  } catch (e) {
    console.error('Failed to load experts', e);
  }
}

function updateCategoryCountTitle(count) {
  const title = document.getElementById('expert-results-count');
  if (title) {
    title.textContent = `${count} expert${count === 1 ? '' : 's'} available in ${activeCategory === 'All' ? 'all fields' : activeCategory}`;
  }
}

function renderExperts(experts) {
  const grid = document.getElementById('experts-grid');
  if (!grid) return;

  if (experts.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; background: rgba(255,255,255,0.04); border: 1.5px dashed rgba(255,255,255,0.15); border-radius: var(--radius-lg); padding: 50px 20px;">
        <div style="font-size: 2.8rem; margin-bottom: 12px;">🔍</div>
        <h3 style="color: var(--white); font-family: 'Syne', sans-serif; font-size: 1.3rem;">No experts found in this category</h3>
        <p style="color: rgba(255,255,255,0.5); font-size: 0.95rem; margin: 8px auto 20px; max-width: 420px;">
          Try searching for a different keyword or be the first expert to join this service!
        </p>
        <button class="btn-primary-lg" onclick="openAddExpertModal()" style="font-size:0.9rem;padding:10px 24px">
          + Join as Expert in ${activeCategory}
        </button>
      </div>
    `;
    return;
  }

  grid.innerHTML = experts.map(exp => `
    <div class="expert-card" id="expert-card-${exp.id}">
      <div class="expert-top">
        <div class="expert-av" style="background: ${exp.avatarBg || 'linear-gradient(135deg,#1B4FD8,#6B21A8)'}">
          ${exp.avatarText || 'NX'}
        </div>
        <div class="expert-info" style="flex:1">
          <div class="name">${exp.name}</div>
          <div class="role">${exp.role}</div>
          <div style="font-size:0.75rem; color: rgba(255,255,255,0.45); margin-top:2px">
            📍 ${exp.location || 'India'} · ${exp.experience || 1}+ yrs exp
          </div>
        </div>
        <div class="verified">✓ ${exp.badge || 'Verified'}</div>
      </div>

      <p style="color: rgba(255,255,255,0.75); font-size: 0.85rem; line-height: 1.5; margin-bottom: 14px; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">
        ${exp.bio || ''}
      </p>

      <div class="expert-skills">
        ${(exp.skills || []).map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
      </div>

      <div class="expert-footer">
        <div>
          <div class="expert-rate">₹${exp.rate} <small>/ ${exp.rateUnit || 'hr'}</small></div>
          <div class="stars">
            ★ <span style="font-weight:700; color:var(--white)">${exp.rating || 5.0}</span>
            <span style="color:rgba(255,255,255,0.45);font-size:.78rem">(${exp.reviewsCount || 1} reviews)</span>
          </div>
        </div>
        <div style="display:flex; gap:8px">
          <button class="btn-view-profile" onclick="viewExpertProfile('${exp.id}')" title="View full profile">Details</button>
          <button class="btn-book" onclick="bookSpecificExpert('${exp.id}')" id="btn-book-${exp.id}">Book Now</button>
        </div>
      </div>
    </div>
  `).join('');
}

function viewExpertProfile(expertId) {
  const exp = allExperts.find(e => e.id === expertId);
  if (!exp) return;

  const content = `
    <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px; border-bottom:1px solid var(--gray-200); padding-bottom:18px">
      <div style="width:64px;height:64px;border-radius:50%;background:${exp.avatarBg};color:white;font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        ${exp.avatarText}
      </div>
      <div>
        <div style="display:flex;align-items:center;gap:8px">
          <h2 style="font-family:'Syne',sans-serif;font-size:1.4rem;color:var(--navy);font-weight:800">${exp.name}</h2>
          <span style="background:#E6FBF2;color:#0D9488;padding:2px 8px;border-radius:100px;font-size:0.75rem;font-weight:600">✓ Verified Pro</span>
        </div>
        <div style="color:var(--gray-700);font-size:0.92rem;font-weight:500;margin-top:2px">${exp.role}</div>
        <div style="color:var(--gray-400);font-size:0.82rem;margin-top:3px">📂 ${exp.category} · 📍 ${exp.location} · 💼 ${exp.experience} Years Exp</div>
      </div>
    </div>

    <div style="margin-bottom:18px">
      <h4 style="font-size:0.85rem;font-weight:700;color:var(--gray-700);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">About Expert</h4>
      <p style="font-size:0.92rem;color:var(--text);line-height:1.6">${exp.bio}</p>
    </div>

    <div style="margin-bottom:20px">
      <h4 style="font-size:0.85rem;font-weight:700;color:var(--gray-700);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Verified Skills & Capabilities</h4>
      <div style="display:flex;flex-wrap:wrap;gap:8px">
        ${(exp.skills || []).map(s => `<span style="background:var(--gray-100);border:1px solid var(--gray-200);color:var(--navy);padding:5px 12px;border-radius:6px;font-size:0.82rem;font-weight:500">${s}</span>`).join('')}
      </div>
    </div>

    <div style="background:var(--gray-100);border-radius:12px;padding:16px 20px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px">
      <div>
        <div style="font-size:0.8rem;color:var(--gray-400)">Service Starting Rate</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--navy)">₹${exp.rate} <span style="font-size:0.8rem;font-weight:400;color:var(--gray-400)">/ ${exp.rateUnit}</span></div>
      </div>
      <div style="text-align:right">
        <div style="font-size:0.8rem;color:var(--gray-400)">Customer Rating</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:700;color:#F59E0B">★ ${exp.rating} <span style="font-size:0.82rem;color:var(--gray-700)">(${exp.reviewsCount} jobs)</span></div>
      </div>
    </div>

    <div style="display:flex;gap:12px">
      <button class="btn-submit" style="background:var(--navy);flex:1" onclick="closeModal()">Close</button>
      <button class="btn-submit" style="background:var(--blue-light);flex:2" onclick="bookSpecificExpert('${exp.id}')">Proceed to Book ${exp.name.split(' ')[0]} →</button>
    </div>
  `;

  document.getElementById('modal-content').innerHTML = content;
  document.getElementById('modal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function bookSpecificExpert(expertId) {
  const exp = allExperts.find(e => e.id === expertId);
  selectedExpertForBooking = exp || null;
  openBookingModal();
}

// ── ADD EXPERT ONBOARDING ──
function openAddExpertModal() {
  const content = `
    <div class="modal-title">Join as Verified Expert</div>
    <p class="modal-sub">List your skills, set your rates, and start receiving verified client bookings.</p>
    <form id="add-expert-form" onsubmit="handleNewExpertSubmit(event)">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" id="new-exp-name" placeholder="e.g. Ramesh Patel" required>
        </div>
        <div class="form-group">
          <label>Specialty / Professional Title *</label>
          <input type="text" id="new-exp-role" placeholder="e.g. Senior Home Electrician" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Service Category *</label>
          <select id="new-exp-category" class="category-dropdown" required>
            <option value="Technology & IT">💻 Technology & IT</option>
            <option value="Teaching & Tutoring">📚 Teaching & Tutoring</option>
            <option value="Home Repairs">🔧 Home Repairs</option>
            <option value="Health & Wellness">⚕️ Health & Wellness</option>
            <option value="Electrical Work">⚡ Electrical Work</option>
            <option value="Design & Creative">🎨 Design & Creative</option>
            <option value="Vehicle Services">🚗 Vehicle Services</option>
            <option value="Cooking & Nutrition">🍳 Cooking & Nutrition</option>
          </select>
        </div>
        <div class="form-group">
          <label>Experience (Years) *</label>
          <input type="number" id="new-exp-exp" min="1" max="40" value="4" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Service Rate (₹) *</label>
          <input type="number" id="new-exp-rate" min="50" max="10000" value="299" required>
        </div>
        <div class="form-group">
          <label>Rate Unit</label>
          <select id="new-exp-unit">
            <option value="hr">Per Hour (/ hr)</option>
            <option value="visit">Per Home Visit (/ visit)</option>
            <option value="session">Per Session (/ session)</option>
            <option value="project">Per Project (/ project)</option>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label>Service City / Location *</label>
        <input type="text" id="new-exp-location" placeholder="e.g. Delhi NCR / Online / Mumbai" required>
      </div>

      <div class="form-group">
        <label>Key Skills & Services (Comma-separated) *</label>
        <input type="text" id="new-exp-skills" placeholder="e.g. Wiring, Inverter Repair, Fuse Check, Lighting" required>
      </div>

      <div class="form-group">
        <label>Professional Bio & Qualifications *</label>
        <textarea id="new-exp-bio" rows="3" style="width:100%;padding:11px 15px;border:1.5px solid var(--gray-200);border-radius:9px;font-family:'DM Sans',sans-serif;font-size:0.93rem;resize:vertical;" placeholder="Describe your background, certifications, warranty, or approach to work..." required></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Mobile Number (For booking alerts) *</label>
          <input type="tel" id="new-exp-phone" placeholder="+91 98765 00000" required>
        </div>
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" id="new-exp-email" placeholder="yourname@gmail.com" required>
        </div>
      </div>

      <button type="submit" class="btn-submit" style="background:var(--blue-light);margin-top:14px" id="btn-submit-expert">
        Publish Profile & Start Earning →
      </button>
    </form>
  `;

  document.getElementById('modal-content').innerHTML = content;
  document.getElementById('modal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

async function handleNewExpertSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('btn-submit-expert');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Registering & Publishing...';
  }

  const payload = {
    name: document.getElementById('new-exp-name').value,
    role: document.getElementById('new-exp-role').value,
    category: document.getElementById('new-exp-category').value,
    experience: document.getElementById('new-exp-exp').value,
    rate: document.getElementById('new-exp-rate').value,
    rateUnit: document.getElementById('new-exp-unit').value,
    location: document.getElementById('new-exp-location').value,
    skills: document.getElementById('new-exp-skills').value,
    bio: document.getElementById('new-exp-bio').value,
    phone: document.getElementById('new-exp-phone').value,
    email: document.getElementById('new-exp-email').value
  };

  try {
    const res = await fetch('/api/experts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      document.getElementById('modal-content').innerHTML = `
        <div style="text-align:center;padding:24px 0;">
          <div style="font-size:3.5rem;margin-bottom:12px;">🎉</div>
          <h2 style="font-family:'Syne',sans-serif;color:var(--navy);font-size:1.5rem;font-weight:800">Welcome to NeedXpert!</h2>
          <p style="color:var(--gray-700);font-size:0.95rem;margin:10px auto 20px;max-width:380px;">
            Your expert profile for <strong>${result.expert.name}</strong> (${result.expert.role}) is now live in <strong>${result.expert.category}</strong>!
          </p>
          <div style="background:var(--gray-100);border-radius:12px;padding:16px;text-align:left;margin-bottom:20px;">
            <div style="font-size:0.85rem;color:var(--gray-400)">Registered ID</div>
            <div style="font-weight:700;color:var(--navy);font-size:0.95rem">${result.expert.id}</div>
          </div>
          <button class="btn-submit" style="background:var(--navy)" onclick="closeModal(); filterByCategory('${result.expert.category}');">
            View Live in ${result.expert.category} →
          </button>
        </div>
      `;
      loadCategories();
      loadExperts();
    } else {
      alert(result.error || 'Failed to add expert.');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Publish Profile & Start Earning →';
      }
    }
  } catch (err) {
    console.error(err);
    alert('Error registering expert. Please try again.');
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Publish Profile & Start Earning →';
    }
  }
}

// ── CUSTOMER BOOKING FLOW ──
function openBookingModal(defaultCat = '') {
  const exp = selectedExpertForBooking;
  const categoryToUse = exp ? exp.category : (defaultCat || activeCategory || 'Technology & IT');
  const feeRate = exp ? exp.rate : 299;
  const unit = exp ? exp.rateUnit : 'visit';
  const total = Number(feeRate) + 49;

  const content = `
    <div class="modal-title">Book a Service Expert</div>
    <p class="modal-sub">${exp ? `You are booking <strong>${exp.name}</strong> (${exp.role})` : 'Choose your requirements and get connected instantly.'}</p>

    <div style="background:#EEF4FF; border:1px solid #C7D9FE; border-radius:10px; padding:12px 16px; margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
      <div>
        <div style="font-size:0.75rem; color:#1B4FD8; font-weight:700; text-transform:uppercase;">Selected Expert / Service</div>
        <div style="font-weight:700; color:var(--navy); font-size:0.95rem;">${exp ? exp.name : 'Verified NeedXpert Pro'}</div>
        <div style="font-size:0.82rem; color:var(--gray-700)">${exp ? exp.role : categoryToUse}</div>
      </div>
      <div style="text-align:right">
        <div style="font-size:0.75rem; color:var(--gray-400)">Service Estimate</div>
        <div style="font-family:'Syne',sans-serif; font-weight:800; font-size:1.1rem; color:var(--blue);">₹${feeRate} <span style="font-size:0.72rem;font-weight:400;color:var(--gray-400)">/${unit}</span></div>
      </div>
    </div>

    <form id="booking-form" onsubmit="proceedToPaymentStep(event)">
      <div class="form-row">
        <div class="form-group">
          <label>Your Full Name *</label>
          <input type="text" id="book-name" placeholder="e.g. Ananya Verma" required>
        </div>
        <div class="form-group">
          <label>Mobile Number *</label>
          <input type="tel" id="book-phone" placeholder="+91 98765 43210" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" id="book-email" placeholder="you@example.com">
        </div>
        <div class="form-group">
          <label>Service Mode</label>
          <select id="book-type">
            <option value="In-Person Visit">🏠 In-Person Doorstep Visit</option>
            <option value="Online Consultation">💻 Online Video / Remote Call</option>
          </select>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Preferred Date *</label>
          <input type="date" id="book-date" required value="${new Date(Date.now() + 86400000).toISOString().split('T')[0]}">
        </div>
        <div class="form-group">
          <label>Preferred Time Slot *</label>
          <select id="book-time">
            <option value="09:00 AM - 12:00 PM">Morning (09:00 AM - 12:00 PM)</option>
            <option value="12:00 PM - 03:00 PM">Afternoon (12:00 PM - 03:00 PM)</option>
            <option value="03:00 PM - 06:00 PM">Evening (03:00 PM - 06:00 PM)</option>
            <option value="06:00 PM - 09:00 PM">Late Evening (06:00 PM - 09:00 PM)</option>
          </select>
        </div>
      </div>

      <!-- SECTION: STATE & DISTRICT (SERVICE LOCATION) -->
      <div style="background:var(--gray-100); border:1.5px solid var(--gray-200); border-radius:12px; padding:16px 16px 10px; margin:16px 0;">
        <div style="font-weight:700; font-size:0.92rem; color:var(--navy); margin-bottom:12px; display:flex; align-items:center; justify-content:space-between;">
          <div style="display:flex; align-items:center; gap:6px;">
            <span>📍</span> <span>Service Location Details (State & District)</span>
          </div>
          <span style="font-size:0.75rem; color:var(--blue); font-weight:600; background:rgba(27,79,216,0.1); padding:2px 8px; border-radius:100px;">Required</span>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>State / Union Territory *</label>
            <select id="book-state" onchange="onBookingStateChange(this.value)" required>
              <option value="">-- Select State / UT --</option>
              ${Object.keys(INDIA_STATES_DISTRICTS).sort().map(s => `<option value="${s}">${s}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label>District / City *</label>
            <select id="book-district" onchange="onBookingDistrictChange(this.value)" required disabled>
              <option value="">-- Select State First --</option>
            </select>
            <input type="text" id="book-district-custom" placeholder="Type your District / City name" style="display:none;margin-top:8px;">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group" style="flex:2">
            <label>Street Address / Flat / Landmark *</label>
            <input type="text" id="book-address" placeholder="Flat No., Building, Street / Locality, Landmark" required>
          </div>
          <div class="form-group" style="flex:1">
            <label>PIN Code *</label>
            <input type="text" id="book-pincode" placeholder="e.g. 110001" maxlength="6" pattern="[0-9]{6}" required>
          </div>
        </div>
      </div>

      <div class="form-group">
        <label>Task Description / Problem Details</label>
        <input type="text" id="book-desc" placeholder="Briefly describe what needs to be repaired or taught...">
      </div>

      <div style="background:var(--gray-100); border-radius:10px; padding:14px; margin:16px 0;">
        <div style="display:flex; justify-content:space-between; font-size:0.85rem; color:var(--gray-700); margin-bottom:6px;">
          <span>Expert Service Fee (Payable on completion)</span>
          <span>₹${feeRate}</span>
        </div>
        <div style="display:flex; justify-content:space-between; font-size:0.85rem; color:var(--gray-700); margin-bottom:8px;">
          <span>NeedXpert Platform Protection & Insurance Fee</span>
          <span style="font-weight:600; color:var(--navy)">₹49</span>
        </div>
        <div style="border-top:1px solid var(--gray-200); padding-top:8px; display:flex; justify-content:space-between; font-size:0.95rem; font-weight:700; color:var(--navy);">
          <span>Due Now (Booking Confirmation)</span>
          <span style="font-family:'Syne',sans-serif; color:var(--blue); font-size:1.1rem;">₹49</span>
        </div>
      </div>

      <button type="submit" class="btn-submit" style="background:var(--blue-light)">
        Proceed to Secure Payment (₹49) →
      </button>
    </form>
  `;

  document.getElementById('modal-content').innerHTML = content;
  document.getElementById('modal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

let pendingBookingPayload = null;

function proceedToPaymentStep(e) {
  e.preventDefault();
  const exp = selectedExpertForBooking;
  const name = document.getElementById('book-name').value;
  const phone = document.getElementById('book-phone').value;
  const email = document.getElementById('book-email').value;
  const date = document.getElementById('book-date').value;
  const time = document.getElementById('book-time').value;
  const type = document.getElementById('book-type').value;
  const state = document.getElementById('book-state').value;
  
  const districtSelect = document.getElementById('book-district').value;
  let district = districtSelect;
  if (districtSelect === 'Other (Custom)') {
    district = document.getElementById('book-district-custom')?.value || 'Other';
  }

  const pincode = document.getElementById('book-pincode')?.value || '';
  const streetAddress = document.getElementById('book-address').value;
  const desc = document.getElementById('book-desc').value;

  const fullAddress = `${streetAddress}, ${district}, ${state}${pincode ? ' - ' + pincode : ''}`;

  pendingBookingPayload = {
    customerName: name,
    customerPhone: phone,
    customerEmail: email,
    expertId: exp ? exp.id : 'exp-general',
    expertName: exp ? exp.name : 'NeedXpert Verified Specialist',
    expertRole: exp ? exp.role : 'Service Specialist',
    expertPhone: exp ? exp.phone : '+91 98765 00000',
    serviceCategory: exp ? exp.category : activeCategory,
    serviceDescription: desc || 'Requested assistance',
    serviceDate: date,
    serviceTimeSlot: time,
    serviceAddress: fullAddress,
    state: state,
    district: district,
    pincode: pincode,
    serviceType: type,
    feeService: exp ? exp.rate : 299,
    feePlatform: 49
  };

  renderPaymentGatewayUI();
}

// ── PAYMENT GATEWAY INTEGRATION ──
function renderPaymentGatewayUI() {
  const p = pendingBookingPayload;
  if (!p) return;

  const upiDeepLink = `upi://pay?pa=ajaycivil@ybl&pn=NeedXpert&am=49&cu=INR&tn=Booking+${encodeURIComponent(p.customerName)}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiDeepLink)}`;

  const content = `
    <div class="modal-title">Complete Payment</div>
    <p class="modal-sub">Secure checkout of ₹49 for booking verification.</p>

    <div style="background:var(--gray-100);border-radius:10px;padding:14px 16px;margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;">
      <div>
        <div style="font-size:0.75rem;color:var(--gray-400);text-transform:uppercase;font-weight:700">Booking Summary</div>
        <div style="font-weight:700;color:var(--navy)">${p.customerName} · ${p.serviceCategory}</div>
        <div style="font-size:0.82rem;color:var(--blue);font-weight:600;margin-top:2px">📍 ${p.district}, ${p.state}</div>
      </div>
      <div style="text-align:right">
        <div style="font-size:0.75rem;color:var(--gray-400)">Amount Payable</div>
        <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:1.25rem;color:var(--navy)">₹49</div>
      </div>
    </div>

    <div class="form-group"><label>Select Payment Gateway</label>
      <div class="pay-methods" style="grid-template-columns:repeat(4,1fr)">
        <div class="pay-option ${currentGateway === 'phonepe' ? 'active' : ''}" onclick="selectGateway('phonepe')">
          <span style="font-size:1.3rem">📱</span>
          <span>PhonePe / UPI</span>
          <small>Instant QR / App</small>
        </div>
        <div class="pay-option ${currentGateway === 'razorpay' ? 'active' : ''}" onclick="selectGateway('razorpay')">
          <span style="font-size:1.3rem">💳</span>
          <span>Razorpay</span>
          <small>Cards, NetBanking</small>
        </div>
        <div class="pay-option ${currentGateway === 'stripe' ? 'active' : ''}" onclick="selectGateway('stripe')">
          <span style="font-size:1.3rem">🌐</span>
          <span>Stripe</span>
          <small>Credit/Debit Cards</small>
        </div>
        <div class="pay-option ${currentGateway === 'cash' ? 'active' : ''}" onclick="selectGateway('cash')">
          <span style="font-size:1.3rem">💵</span>
          <span>Pay at Door</span>
          <small>Direct to Expert</small>
        </div>
      </div>
    </div>

    <!-- PhonePe Form -->
    <div id="pay-phonepe" class="pay-form" style="display:${currentGateway === 'phonepe' ? 'block' : 'none'}">
      <div style="background:linear-gradient(135deg,#5f259f11,#5f259f22);border:1.5px solid #5f259f44;border-radius:14px;padding:20px;text-align:center;margin-bottom:14px;">
        <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:1.05rem;color:#5f259f;margin-bottom:4px;">Pay via PhonePe / GPay / Paytm / Any UPI</div>
        <div style="font-size:.82rem;color:var(--gray-700);margin-bottom:12px;">Scan this QR code with any UPI app on your phone</div>
        
        <img src="${qrUrl}" alt="UPI QR" style="width:160px;height:160px;border-radius:10px;border:3px solid #5f259f33;margin-bottom:12px;box-shadow:0 4px 12px rgba(95,37,159,0.15)">
        
        <div style="display:flex;justify-content:center;align-items:center;gap:8px;margin-bottom:12px;">
          <span style="font-size:0.85rem;color:var(--gray-700)">UPI ID: <strong>ajaycivil@ybl</strong></span>
          <button type="button" onclick="copyUPI()" style="background:#5f259f;color:white;border:none;border-radius:6px;padding:3px 10px;font-size:0.75rem;cursor:pointer;">Copy</button>
        </div>

        <a href="${upiDeepLink}" style="display:inline-block;background:#5f259f;color:white;border-radius:8px;padding:10px 24px;font-size:0.88rem;font-weight:600;text-decoration:none;margin-bottom:6px">
          Open UPI App on Phone →
        </a>
      </div>
    </div>

    <!-- Razorpay Form -->
    <div id="pay-razorpay" class="pay-form" style="display:${currentGateway === 'razorpay' ? 'block' : 'none'}">
      <div style="background:#FFF9F0;border:1.5px solid #F4A21E44;border-radius:14px;padding:20px;margin-bottom:14px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
          <span style="font-size:1.4rem">🇮🇳</span>
          <h4 style="font-family:'Syne',sans-serif;color:var(--navy);font-size:1rem;margin:0">Razorpay Gateway Simulation</h4>
        </div>
        <p style="font-size:0.85rem;color:var(--gray-700);line-height:1.5;margin-bottom:12px">
          Supports instant payments via NetBanking (SBI, HDFC, ICICI, Axis), Debit/Credit Cards, and Wallets.
        </p>
        <div style="background:white;border:1px solid var(--gray-200);border-radius:8px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:0.85rem;color:var(--gray-700)">Test Mode Payment</span>
          <span style="background:#E6FBF2;color:#0D9488;font-size:0.75rem;padding:2px 8px;border-radius:6px;font-weight:600">✓ Ready to Authorize</span>
        </div>
      </div>
    </div>

    <!-- Stripe Form -->
    <div id="pay-stripe" class="pay-form" style="display:${currentGateway === 'stripe' ? 'block' : 'none'}">
      <div style="background:#F4F8FF;border:1.5px solid #2D6AFF33;border-radius:14px;padding:20px;margin-bottom:14px;">
        <div class="form-group">
          <label>Card Number</label>
          <input type="text" placeholder="4242 •••• •••• 4242" value="4242 8192 3847 9102" maxlength="19" oninput="fmtCard(this)">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Expiry (MM/YY)</label>
            <input type="text" placeholder="12 / 28" value="12 / 28" maxlength="7" oninput="fmtExp(this)">
          </div>
          <div class="form-group">
            <label>CVV</label>
            <input type="password" placeholder="888" value="888" maxlength="4">
          </div>
        </div>
        <div style="font-size:0.75rem;color:var(--gray-400)">🔒 256-bit encrypted card transmission.</div>
      </div>
    </div>

    <!-- Cash Form -->
    <div id="pay-cash" class="pay-form" style="display:${currentGateway === 'cash' ? 'block' : 'none'}">
      <div style="background:#F0FDF4;border:1.5px solid #10B98144;border-radius:14px;padding:20px;text-align:center;margin-bottom:14px;">
        <div style="font-size:2rem;margin-bottom:8px">🤝</div>
        <h4 style="font-family:'Syne',sans-serif;color:#047857;font-size:1rem;margin-bottom:6px">Pay ₹49 Platform Fee + Balance on Arrival</h4>
        <p style="font-size:0.85rem;color:var(--gray-700);line-height:1.5">
          Confirm your slot now. Pay the expert via cash or UPI directly when they visit your premises.
        </p>
      </div>
    </div>

    <div style="display:flex;gap:12px">
      <button type="button" class="btn-submit" style="background:var(--gray-200);color:var(--navy);flex:1" onclick="openBookingModal()">
        ← Back
      </button>
      <button type="button" class="btn-submit" style="background:var(--blue);flex:2" id="btn-confirm-payment" onclick="processFinalPayment()">
        Pay ₹49 & Confirm Booking →
      </button>
    </div>
  `;

  document.getElementById('modal-content').innerHTML = content;
}

function selectGateway(gateway) {
  currentGateway = gateway;
  document.querySelectorAll('.pay-option').forEach(o => o.classList.remove('active'));
  document.querySelectorAll('.pay-form').forEach(f => f.style.display = 'none');
  const targetForm = document.getElementById(`pay-${gateway}`);
  if (targetForm) targetForm.style.display = 'block';
  renderPaymentGatewayUI();
}

async function processFinalPayment() {
  const btn = document.getElementById('btn-confirm-payment');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Verifying Transaction... ⏳';
  }

  const p = pendingBookingPayload;
  if (!p) return;

  try {
    // 1. Process payment via server
    const payRes = await fetch('/api/payments/process', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: 49,
        gateway: currentGateway,
        customerPhone: p.customerPhone,
        bookingData: p
      })
    });
    const payData = await payRes.json();

    // 2. Create the real confirmed booking
    p.paymentMethod = currentGateway.toUpperCase();
    p.paymentStatus = 'Paid';
    p.transactionId = payData.transactionId || `TXN-${Date.now()}`;

    const bookRes = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(p)
    });
    const bookData = await bookRes.json();

    if (bookData.success && bookData.booking) {
      showPaymentSuccessModal(bookData.booking);
    } else {
      alert('Error finalizing booking. Please try again.');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Pay ₹49 & Confirm Booking →';
      }
    }
  } catch (err) {
    console.error(err);
    alert('Payment processing failed. Please check network.');
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Pay ₹49 & Confirm Booking →';
    }
  }
}

function showPaymentSuccessModal(booking) {
  const locationText = (booking.district && booking.state) 
    ? `${booking.district}, ${booking.state}`
    : (booking.state || booking.district || booking.serviceAddress);

  const content = `
    <div style="text-align:center;padding:20px 0;">
      <div style="width:70px;height:70px;background:#E6FBF2;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:2.2rem;color:#10B981">
        ✓
      </div>
      <div class="modal-title" style="text-align:center">Booking Confirmed!</div>
      <p class="modal-sub" style="text-align:center;margin-top:6px">Your service has been registered with NeedXpert.</p>

      <div style="background:var(--gray-100);border-radius:14px;padding:20px;margin:20px 0;text-align:left;">
        <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:0.9rem;">
          <span style="color:var(--gray-400)">Booking ID</span>
          <span style="font-weight:700;color:var(--blue);font-family:'Syne',sans-serif;font-size:1.05rem;">${booking.id}</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:0.9rem;">
          <span style="color:var(--gray-400)">Assigned Expert</span>
          <span style="font-weight:600;color:var(--navy)">${booking.expertName}</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:0.9rem;">
          <span style="color:var(--gray-400)">Service Location</span>
          <span style="font-weight:600;color:var(--navy);text-align:right">📍 ${locationText}</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:0.9rem;">
          <span style="color:var(--gray-400)">Scheduled Slot</span>
          <span style="font-weight:500;color:var(--text)">${booking.serviceDate} (${booking.serviceTimeSlot})</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:0.9rem;">
          <span style="color:var(--gray-400)">Service Start OTP</span>
          <span style="font-family:'Syne',sans-serif;font-weight:800;background:var(--navy);color:var(--white);padding:2px 8px;border-radius:6px;font-size:0.95rem;">${booking.serviceOtp}</span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:0.9rem;border-top:1px solid var(--gray-200);padding-top:10px;margin-top:10px">
          <span style="color:var(--gray-400)">Payment Status</span>
          <span style="font-weight:700;color:#10B981">✓ Paid ₹${booking.feePlatform} (${booking.paymentMethod})</span>
        </div>
      </div>

      <div style="display:flex;gap:10px">
        <button class="btn-submit" style="background:var(--navy);flex:1" onclick="closeModal();trackService('${booking.id}');">
          🔍 Track Status Live
        </button>
        <button class="btn-submit" style="background:var(--blue-light);flex:1" onclick="downloadInvoice('${booking.id}')">
          📄 Download Slip
        </button>
      </div>
    </div>
  `;

  document.getElementById('modal-content').innerHTML = content;
}

// ── SERVICE STATUS TRACKER ──
async function trackService(bookingIdInput) {
  const idOrPhone = bookingIdInput || document.getElementById('tracker-search-input')?.value;
  if (!idOrPhone) {
    alert('Please enter a Booking ID (e.g. NX-2026-8421) or registered Phone Number.');
    return;
  }

  const container = document.getElementById('tracker-result-container');
  if (container) {
    container.innerHTML = `<div style="text-align:center;padding:40px;"><div class="spinner"></div><p style="margin-top:10px;color:var(--gray-400)">Retrieving live service status...</p></div>`;
  }

  try {
    const res = await fetch(`/api/bookings?query=${encodeURIComponent(idOrPhone)}`);
    const data = await res.json();

    if (data.success && data.bookings && data.bookings.length > 0) {
      const booking = data.bookings[0];
      activeTrackedBooking = booking;
      renderTrackerResult(booking);
    } else {
      if (container) {
        container.innerHTML = `
          <div style="background:var(--white);border:1.5px dashed var(--gray-200);border-radius:var(--radius-lg);padding:40px;text-align:center;">
            <div style="font-size:2.5rem;margin-bottom:10px">⚠️</div>
            <h3 style="font-family:'Syne',sans-serif;color:var(--navy);font-size:1.2rem;">No Booking Found</h3>
            <p style="color:var(--gray-400);font-size:0.9rem;margin:6px 0 18px;">
              We couldn't locate any booking matching "<strong>${idOrPhone}</strong>".
            </p>
            <p style="font-size:0.85rem;color:var(--gray-700)">
              Try one of our demo booking IDs: <button onclick="trackService('NX-2026-8421')" style="color:var(--blue);background:none;border:none;cursor:pointer;text-decoration:underline;font-weight:600">NX-2026-8421</button> or <button onclick="trackService('NX-2026-7210')" style="color:var(--blue);background:none;border:none;cursor:pointer;text-decoration:underline;font-weight:600">NX-2026-7210</button>
            </p>
          </div>
        `;
      }
    }
  } catch (err) {
    console.error(err);
  }
}

function renderTrackerResult(b) {
  const container = document.getElementById('tracker-result-container');
  if (!container) return;

  const statusColors = {
    booked: { text: 'Booking Placed', bg: '#EFF6FF', color: '#1D4ED8' },
    confirmed: { text: 'Expert Confirmed', bg: '#FEF3C7', color: '#B45309' },
    in_progress: { text: 'In Progress / On The Way', bg: '#ECFDF5', color: '#047857' },
    completed: { text: 'Completed & Closed', bg: '#E6FBF2', color: '#065F46' },
    cancelled: { text: 'Cancelled', bg: '#FEE2E2', color: '#991B1B' }
  };

  const st = statusColors[b.serviceStatus] || statusColors.confirmed;

  container.innerHTML = `
    <div style="background:var(--white);border-radius:var(--radius-lg);padding:36px;box-shadow:0 12px 36px rgba(11,22,40,0.06);border:1.5px solid var(--gray-200);animation:fadeUp .4s ease both">
      <!-- Top header with ID & Status -->
      <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1px solid var(--gray-200);padding-bottom:20px;flex-wrap:wrap;gap:12px">
        <div>
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--navy)">${b.id}</span>
            <span style="background:${st.bg};color:${st.color};padding:4px 14px;border-radius:100px;font-size:0.8rem;font-weight:700">● ${st.text}</span>
          </div>
          <p style="color:var(--gray-400);font-size:0.88rem;margin-top:4px">Category: <strong>${b.serviceCategory}</strong> · Mode: <strong>${b.serviceType}</strong></p>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn-outline-white" style="color:var(--navy);border-color:var(--gray-200);background:var(--gray-100);font-size:0.82rem;padding:7px 14px" onclick="downloadInvoice('${b.id}')">
            📄 Invoice
          </button>
          <button class="btn-accent" style="font-size:0.82rem;padding:7px 14px" onclick="advanceBookingStatus('${b.id}')" title="Test workflow step">
            ⚡ Advance Status Demo
          </button>
        </div>
      </div>

      <!-- Main 2-column info -->
      <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:32px;margin:28px 0;align-items:flex-start;">
        <!-- Left: Stepper Timeline -->
        <div>
          <h4 style="font-family:'Syne',sans-serif;color:var(--navy);font-size:1.05rem;margin-bottom:18px">Live Service Milestones</h4>
          <div class="tracker-timeline">
            ${(b.timeline || []).map((step, idx) => `
              <div class="timeline-step ${step.done ? 'completed' : ''}">
                <div class="step-indicator">${step.done ? '✓' : (idx + 1)}</div>
                <div class="step-details">
                  <div style="font-weight:700;color:${step.done ? 'var(--navy)' : 'var(--gray-400)'};font-size:0.95rem">${step.title}</div>
                  <div style="font-size:0.82rem;color:var(--gray-700);margin:3px 0">${step.desc}</div>
                  <div style="font-size:0.75rem;color:var(--gray-400)">🕒 ${step.time}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Right: Expert card & OTP details -->
        <div style="background:var(--gray-100);border-radius:16px;padding:24px;">
          <h4 style="font-family:'Syne',sans-serif;color:var(--navy);font-size:0.95rem;margin-bottom:14px;text-transform:uppercase;letter-spacing:0.5px">Assigned Expert</h4>
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:50%;background:var(--navy);color:white;font-family:'Syne',sans-serif;font-weight:700;display:flex;align-items:center;justify-content:center;font-size:1.1rem">
              ${b.expertName.split(' ').map(n=>n[0]).join('').substring(0,2)}
            </div>
            <div>
              <div style="font-weight:700;color:var(--navy);font-size:1rem">${b.expertName}</div>
              <div style="font-size:0.8rem;color:var(--gray-400)">${b.expertRole}</div>
            </div>
          </div>

          <div style="background:var(--white);border-radius:10px;padding:14px;margin-bottom:14px">
            <div style="font-size:0.78rem;color:var(--gray-400);margin-bottom:2px">Service Start OTP (Provide when expert arrives)</div>
            <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:1.6rem;letter-spacing:3px;color:var(--blue)">
              ${b.serviceOtp || '4829'}
            </div>
          </div>

          <div style="font-size:0.84rem;color:var(--gray-700);line-height:1.6;margin-bottom:16px">
            <div>📍 <strong>Address:</strong> ${b.serviceAddress}</div>
            ${(b.district || b.state) ? `<div>🏛️ <strong>District & State:</strong> ${b.district ? b.district + ', ' : ''}${b.state || ''} ${b.pincode ? '(' + b.pincode + ')' : ''}</div>` : ''}
            <div>📅 <strong>Date:</strong> ${b.serviceDate} (${b.serviceTimeSlot})</div>
            <div>💰 <strong>Fee Total:</strong> ₹${b.feeTotal} (Platform Fee: ₹${b.feePlatform} Paid)</div>
          </div>

          <div style="display:flex;gap:8px">
            <button class="btn-submit" style="background:#25D366;font-size:0.85rem;padding:9px" onclick="alert('Connecting to ${b.expertName} via WhatsApp / Call at ${b.expertPhone}...')">
              💬 WhatsApp Expert
            </button>
            ${b.serviceStatus === 'completed' && !b.rating ? `
              <button class="btn-submit" style="background:#F59E0B;font-size:0.85rem;padding:9px" onclick="openReviewModal('${b.id}')">
                ★ Rate & Review
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    </div>
  `;
}

async function advanceBookingStatus(bookingId) {
  const b = activeTrackedBooking;
  if (!b) return;

  const flow = ['booked', 'confirmed', 'in_progress', 'completed'];
  const curIdx = flow.indexOf(b.serviceStatus);
  const nextStatus = flow[(curIdx + 1) % flow.length];

  try {
    const res = await fetch(`/api/bookings/${bookingId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus })
    });
    const data = await res.json();
    if (data.success) {
      activeTrackedBooking = data.booking;
      renderTrackerResult(data.booking);
    }
  } catch (e) {
    console.error(e);
  }
}

function openReviewModal(bookingId) {
  const content = `
    <div class="modal-title">Rate Your Experience</div>
    <p class="modal-sub">How was your service with <strong>${activeTrackedBooking?.expertName}</strong>?</p>
    <div style="display:flex;justify-content:center;gap:12px;font-size:2.2rem;cursor:pointer;margin:20px 0;" id="star-rating-picker">
      <span onclick="setRating(1)">★</span>
      <span onclick="setRating(2)">★</span>
      <span onclick="setRating(3)">★</span>
      <span onclick="setRating(4)">★</span>
      <span onclick="setRating(5)" style="color:#F59E0B">★</span>
    </div>
    <div class="form-group">
      <label>Your Feedback / Review</label>
      <textarea id="review-text" rows="3" style="width:100%;padding:10px;border:1.5px solid var(--gray-200);border-radius:8px" placeholder="Share your experience..."></textarea>
    </div>
    <button class="btn-submit" style="background:var(--navy)" onclick="submitReview('${bookingId}')">Submit Review & Rating →</button>
  `;
  document.getElementById('modal-content').innerHTML = content;
  document.getElementById('modal').classList.add('active');
}

let selectedRatingValue = 5;
function setRating(val) {
  selectedRatingValue = val;
  const stars = document.querySelectorAll('#star-rating-picker span');
  stars.forEach((s, idx) => {
    s.style.color = idx < val ? '#F59E0B' : '#E8EBF4';
  });
}

async function submitReview(bookingId) {
  const text = document.getElementById('review-text')?.value;
  try {
    const res = await fetch(`/api/bookings/${bookingId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating: selectedRatingValue, reviewText: text })
    });
    const data = await res.json();
    if (data.success) {
      alert('Thank you! Your rating has been recorded.');
      closeModal();
      trackService(bookingId);
      loadExperts();
    }
  } catch (e) {
    console.error(e);
  }
}

function downloadInvoice(bookingId) {
  const b = activeTrackedBooking || { id: bookingId, customerName: 'Valued Customer', expertName: 'NeedXpert Specialist', feeTotal: 448, feePlatform: 49, paymentMethod: 'UPI' };
  const invoiceHtml = `
    <html>
      <head>
        <title>Invoice - ${b.id}</title>
        <style>
          body { font-family: sans-serif; padding: 40px; color: #1A1F36; line-height: 1.6; }
          .header { display: flex; justify-content: space-between; border-bottom: 2px solid #0B1628; padding-bottom: 20px; margin-bottom: 30px; }
          .logo { font-size: 24px; font-weight: bold; color: #0B1628; }
          .logo span { color: #F4A21E; }
          table { width: 100%; border-collapse: collapse; margin: 30px 0; }
          th, td { padding: 12px; text-align: left; border-bottom: 1px solid #E8EBF4; }
          th { background: #F7F8FC; font-size: 13px; text-transform: uppercase; }
          .total-box { text-align: right; margin-top: 20px; font-size: 18px; font-weight: bold; }
          .stamp { display: inline-block; border: 2px dashed #10B981; color: #10B981; padding: 8px 16px; border-radius: 6px; font-weight: bold; margin-top: 20px; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <div class="logo">Need<span>Xpert</span></div>
            <p>NeedXpert Services Pvt. Ltd.<br>GSTIN: 07AAACN9218P1ZX<br>support@needxpert.com</p>
          </div>
          <div style="text-align:right">
            <h2>TAX INVOICE</h2>
            <p><strong>Invoice ID:</strong> INV-${b.id}<br><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
          </div>
        </div>
        <div>
          <strong>Billed To:</strong><br>
          ${b.customerName}<br>
          Phone: ${b.customerPhone || 'N/A'}<br>
          Address: ${b.serviceAddress || 'Online'}
        </div>
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th>Assigned Specialist</th>
              <th>Rate / Unit</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Platform Security & Insurance Fee</td>
              <td>NeedXpert Protection</td>
              <td>1</td>
              <td>₹49.00</td>
            </tr>
            <tr>
              <td>Professional Service Fee</td>
              <td>${b.expertName} (${b.serviceCategory || 'Service'})</td>
              <td>1</td>
              <td>₹${(b.feeService || 399)}.00</td>
            </tr>
          </tbody>
        </table>
        <div class="total-box">
          Total Amount: ₹${b.feeTotal || 448}.00<br>
          <small style="color:#0D9488;font-size:13px">Platform Fee Paid via ${b.paymentMethod || 'UPI'} ✓</small>
        </div>
        <div class="stamp">PAID & VERIFIED</div>
        <script>window.print();</script>
      </body>
    </html>
  `;
  const win = window.open('', '_blank');
  if (win) {
    win.document.write(invoiceHtml);
    win.document.close();
  }
}

// ── EVENT LISTENERS & SEARCH ──
function setupEventListeners() {
  const searchInput = document.getElementById('expert-search-input');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        searchQuery = e.target.value;
        loadExperts();
      }, 250);
    });
  }

  const sortSelect = document.getElementById('expert-sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      sortBy = e.target.value;
      loadExperts();
    });
  }
}

function copyUPI() {
  navigator.clipboard.writeText('ajaycivil@ybl').then(() => {
    alert('UPI ID ajaycivil@ybl copied to clipboard!');
  });
}

function fmtCard(input) {
  let v = input.value.replace(/\D/g, '').substring(0, 16);
  input.value = v.replace(/(.{4})/g, '$1 ').trim();
}

function fmtExp(input) {
  let v = input.value.replace(/\D/g, '').substring(0, 4);
  if (v.length >= 2) v = v.substring(0, 2) + ' / ' + v.substring(2);
  input.value = v;
}
