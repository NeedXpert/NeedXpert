import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(__dirname));

const DATA_DIR = path.join(__dirname, 'data');
const EXPERTS_FILE = path.join(DATA_DIR, 'experts.json');
const BOOKINGS_FILE = path.join(DATA_DIR, 'bookings.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readJsonFile(filePath, defaultData = []) {
  try {
    if (!fs.existsSync(filePath)) {
      fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2), 'utf-8');
      return defaultData;
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data || '[]');
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return defaultData;
  }
}

function writeJsonFile(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
    return false;
  }
}

// ── API ROUTES ──

// GET /api/categories
app.get('/api/categories', (req, res) => {
  const experts = readJsonFile(EXPERTS_FILE);
  const categoriesMap = {
    'Technology & IT': { icon: '💻', count: 0, description: 'Web dev, App development, IT support, Cloud & Cyber security' },
    'Teaching & Tutoring': { icon: '📚', count: 0, description: 'K-12, Math, Science, Language, JEE/NEET & Competitive Exams' },
    'Home Repairs': { icon: '🔧', count: 0, description: 'AC repair, Appliances, Plumbing, Carpentry, Painting & Handyman' },
    'Health & Wellness': { icon: '⚕️', count: 0, description: 'Dietitians, Yoga trainers, Physiotherapists & Fitness coaches' },
    'Electrical Work': { icon: '⚡', count: 0, description: 'Licensed electricians, Short circuit fix, Smart home wiring' },
    'Design & Creative': { icon: '🎨', count: 0, description: 'Graphic design, UI/UX, Video editing, Brand identity & Animation' },
    'Vehicle Services': { icon: '🚗', count: 0, description: 'Car & Bike doorstep mechanics, OBD Diagnostics, Battery replacement' },
    'Cooking & Nutrition': { icon: '🍳', count: 0, description: 'Private chefs, Event catering, Healthy meal prep & Baking' }
  };

  experts.forEach(exp => {
    if (exp.category && categoriesMap[exp.category]) {
      categoriesMap[exp.category].count += 1;
    } else if (exp.category) {
      categoriesMap[exp.category] = { icon: '⭐', count: 1, description: 'Professional skilled services' };
    }
  });

  const categoryList = Object.keys(categoriesMap).map(name => ({
    name,
    icon: categoriesMap[name].icon,
    count: categoriesMap[name].count,
    description: categoriesMap[name].description
  }));

  res.json({ success: true, categories: categoryList });
});

// GET /api/experts
app.get('/api/experts', (req, res) => {
  const { category, search, sort } = req.query;
  let experts = readJsonFile(EXPERTS_FILE);

  if (category && category !== 'All') {
    experts = experts.filter(e => e.category?.toLowerCase() === category.toLowerCase());
  }

  if (search) {
    const q = search.toLowerCase();
    experts = experts.filter(e => 
      e.name?.toLowerCase().includes(q) ||
      e.role?.toLowerCase().includes(q) ||
      e.category?.toLowerCase().includes(q) ||
      e.location?.toLowerCase().includes(q) ||
      (e.skills && e.skills.some(s => s.toLowerCase().includes(q)))
    );
  }

  if (sort === 'rating') {
    experts.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  } else if (sort === 'price_low') {
    experts.sort((a, b) => (a.rate || 0) - (b.rate || 0));
  } else if (sort === 'price_high') {
    experts.sort((a, b) => (b.rate || 0) - (a.rate || 0));
  } else if (sort === 'experience') {
    experts.sort((a, b) => (b.experience || 0) - (a.experience || 0));
  }

  res.json({ success: true, count: experts.length, experts });
});

// POST /api/experts (Add New Expert)
app.post('/api/experts', (req, res) => {
  try {
    const {
      name,
      role,
      category,
      rate,
      rateUnit = 'hr',
      location,
      experience,
      skills,
      bio,
      phone,
      email
    } = req.body;

    if (!name || !category || !role) {
      return res.status(400).json({ success: false, error: 'Name, Category, and Specialty/Role are required.' });
    }

    const experts = readJsonFile(EXPERTS_FILE);
    
    // Generate initials & color
    const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'NX';
    const gradientColors = [
      'linear-gradient(135deg,#1B4FD8,#6B21A8)',
      'linear-gradient(135deg,#0D9488,#10B981)',
      'linear-gradient(135deg,#DC2626,#F97316)',
      'linear-gradient(135deg,#1B4FD8,#2D6AFF)',
      'linear-gradient(135deg,#EC4899,#8B5CF6)',
      'linear-gradient(135deg,#F59E0B,#EF4444)',
      'linear-gradient(135deg,#3B82F6,#1E40AF)',
      'linear-gradient(135deg,#10B981,#047857)'
    ];
    const avatarBg = gradientColors[Math.floor(Math.random() * gradientColors.length)];

    const parsedSkills = Array.isArray(skills) 
      ? skills 
      : (typeof skills === 'string' ? skills.split(',').map(s => s.trim()).filter(Boolean) : [category]);

    const newExpert = {
      id: 'exp-' + Date.now(),
      name: name.trim(),
      role: role.trim(),
      category: category.trim(),
      rating: 5.0,
      reviewsCount: 1,
      rate: Number(rate) || 299,
      rateUnit: rateUnit || 'hr',
      location: location ? location.trim() : 'India',
      verified: true,
      experience: Number(experience) || 1,
      skills: parsedSkills.length > 0 ? parsedSkills : [role],
      bio: bio ? bio.trim() : `Certified professional offering quality ${category} services.`,
      avatarBg,
      avatarText: initials,
      completedJobs: 0,
      phone: phone || '+91 90000 00000',
      email: email || `${name.toLowerCase().replace(/\s+/g, '.')}@needxpert.com`,
      badge: 'New Verified',
      createdAt: new Date().toISOString()
    };

    experts.unshift(newExpert);
    writeJsonFile(EXPERTS_FILE, experts);

    res.status(201).json({
      success: true,
      message: 'Expert registered and published successfully!',
      expert: newExpert
    });
  } catch (err) {
    console.error('Error creating expert:', err);
    res.status(500).json({ success: false, error: 'Failed to add expert' });
  }
});

// GET /api/bookings (List or search bookings)
app.get('/api/bookings', (req, res) => {
  const { query, phone, email, id } = req.query;
  let bookings = readJsonFile(BOOKINGS_FILE);

  if (id) {
    const booking = bookings.find(b => b.id.toLowerCase() === id.trim().toLowerCase());
    if (booking) return res.json({ success: true, booking });
    return res.status(404).json({ success: false, error: 'Booking not found with ID ' + id });
  }

  if (query) {
    const q = query.trim().toLowerCase();
    bookings = bookings.filter(b => 
      b.id.toLowerCase().includes(q) ||
      b.customerPhone.toLowerCase().includes(q) ||
      b.customerEmail.toLowerCase().includes(q) ||
      b.customerName.toLowerCase().includes(q) ||
      (b.district && b.district.toLowerCase().includes(q)) ||
      (b.state && b.state.toLowerCase().includes(q)) ||
      (b.serviceAddress && b.serviceAddress.toLowerCase().includes(q))
    );
  } else if (phone) {
    const p = phone.replace(/\D/g, '');
    bookings = bookings.filter(b => b.customerPhone.replace(/\D/g, '').includes(p));
  }

  res.json({ success: true, count: bookings.length, bookings });
});

// GET /api/bookings/:id
app.get('/api/bookings/:id', (req, res) => {
  const bookings = readJsonFile(BOOKINGS_FILE);
  const booking = bookings.find(b => b.id.toLowerCase() === req.params.id.trim().toLowerCase());
  if (!booking) {
    return res.status(404).json({ success: false, error: 'Booking ID not found' });
  }
  res.json({ success: true, booking });
});

// POST /api/bookings (Create a new booking)
app.post('/api/bookings', (req, res) => {
  try {
    const {
      customerName,
      customerPhone,
      customerEmail,
      expertId,
      expertName,
      expertRole,
      expertPhone,
      serviceCategory,
      serviceDescription,
      serviceDate,
      serviceTimeSlot,
      serviceAddress,
      state = '',
      district = '',
      pincode = '',
      serviceType = 'In-Person Visit',
      feeService = 299,
      feePlatform = 49,
      paymentMethod = 'PhonePe UPI',
      notes = ''
    } = req.body;

    if (!customerName || !customerPhone) {
      return res.status(400).json({ success: false, error: 'Customer Name and Phone Number are required.' });
    }

    const bookings = readJsonFile(BOOKINGS_FILE);
    const bookingNum = Math.floor(1000 + Math.random() * 9000);
    const bookingId = `NX-2026-${bookingNum}`;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    const nowStr = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

    const newBooking = {
      id: bookingId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail ? customerEmail.trim() : `${customerName.toLowerCase().replace(/\s+/g, '')}@example.com`,
      expertId: expertId || 'exp-general',
      expertName: expertName || 'NeedXpert Verified Specialist',
      expertRole: expertRole || (serviceCategory ? `${serviceCategory} Specialist` : 'Professional Service Expert'),
      expertPhone: expertPhone || '+91 98765 00000',
      serviceCategory: serviceCategory || 'General Service',
      serviceDescription: serviceDescription ? serviceDescription.trim() : 'Requested home/online service assistance.',
      serviceDate: serviceDate || new Date(Date.now() + 86400000).toISOString().split('T')[0],
      serviceTimeSlot: serviceTimeSlot || '10:00 AM - 01:00 PM',
      serviceAddress: serviceAddress || 'Customer Registered Address / Online',
      state: state.trim(),
      district: district.trim(),
      pincode: pincode.trim(),
      serviceType: serviceType || 'In-Person Visit',
      feeService: Number(feeService) || 299,
      feePlatform: Number(feePlatform) || 49,
      feeTotal: (Number(feeService) || 299) + (Number(feePlatform) || 49),
      paymentMethod: paymentMethod || 'PhonePe UPI',
      paymentStatus: 'Paid',
      transactionId: `TXN-${paymentMethod.toUpperCase().substring(0, 4)}-${Date.now().toString().slice(-6)}`,
      serviceStatus: 'confirmed',
      serviceOtp: otp,
      createdAt: new Date().toISOString(),
      timeline: [
        {
          status: 'booked',
          title: 'Booking Received & Platform Fee Paid',
          desc: `Platform security deposit of ₹${feePlatform} confirmed via ${paymentMethod}.`,
          time: nowStr,
          done: true
        },
        {
          status: 'confirmed',
          title: 'Expert Assigned & Confirmed',
          desc: `${expertName || 'Assigned specialist'} received booking for ${serviceDate || 'scheduled slot'}.`,
          time: nowStr,
          done: true
        },
        {
          status: 'in_progress',
          title: 'Service In-Progress / On The Way',
          desc: `Service OTP is ${otp}. Share this with expert upon arrival.`,
          time: 'Upcoming',
          done: false
        },
        {
          status: 'completed',
          title: 'Service Completed & Closed',
          desc: 'Job completion confirmation and invoice release.',
          time: 'Pending',
          done: false
        }
      ],
      notes: notes.trim()
    };

    bookings.unshift(newBooking);
    writeJsonFile(BOOKINGS_FILE, bookings);

    res.status(201).json({
      success: true,
      message: 'Booking created successfully!',
      booking: newBooking
    });
  } catch (err) {
    console.error('Error creating booking:', err);
    res.status(500).json({ success: false, error: 'Failed to create booking' });
  }
});

// PATCH /api/bookings/:id/status (Simulate/Advance booking status)
app.patch('/api/bookings/:id/status', (req, res) => {
  const { status, note } = req.body;
  const bookings = readJsonFile(BOOKINGS_FILE);
  const bookingIndex = bookings.findIndex(b => b.id.toLowerCase() === req.params.id.trim().toLowerCase());

  if (bookingIndex === -1) {
    return res.status(404).json({ success: false, error: 'Booking not found' });
  }

  const validStatuses = ['booked', 'confirmed', 'in_progress', 'completed', 'cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status' });
  }

  const booking = bookings[bookingIndex];
  booking.serviceStatus = status;
  const nowStr = new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

  // Update timeline
  const statusOrder = ['booked', 'confirmed', 'in_progress', 'completed'];
  const targetIdx = statusOrder.indexOf(status);

  if (booking.timeline) {
    booking.timeline.forEach((item, idx) => {
      if (idx <= targetIdx) {
        item.done = true;
        if (idx === targetIdx && (!item.time || item.time.includes('Pending') || item.time.includes('Upcoming'))) {
          item.time = nowStr;
        }
      } else {
        item.done = false;
      }
    });
  }

  if (status === 'completed') {
    booking.completedAt = new Date().toISOString();
  }

  bookings[bookingIndex] = booking;
  writeJsonFile(BOOKINGS_FILE, bookings);

  res.json({ success: true, message: `Status updated to ${status}`, booking });
});

// POST /api/bookings/:id/review (Add star rating and review)
app.post('/api/bookings/:id/review', (req, res) => {
  const { rating, reviewText } = req.body;
  const bookings = readJsonFile(BOOKINGS_FILE);
  const bookingIndex = bookings.findIndex(b => b.id.toLowerCase() === req.params.id.trim().toLowerCase());

  if (bookingIndex === -1) {
    return res.status(404).json({ success: false, error: 'Booking not found' });
  }

  const booking = bookings[bookingIndex];
  booking.rating = Number(rating) || 5;
  booking.review = reviewText || 'Great service!';
  booking.reviewedAt = new Date().toISOString();

  bookings[bookingIndex] = booking;
  writeJsonFile(BOOKINGS_FILE, bookings);

  // Also update expert rating if expertId is known
  if (booking.expertId) {
    const experts = readJsonFile(EXPERTS_FILE);
    const expIndex = experts.findIndex(e => e.id === booking.expertId);
    if (expIndex !== -1) {
      const exp = experts[expIndex];
      const count = (exp.reviewsCount || 0) + 1;
      const currentSum = (exp.rating || 5) * (exp.reviewsCount || 1);
      exp.rating = parseFloat(((currentSum + (Number(rating) || 5)) / count).toFixed(1));
      exp.reviewsCount = count;
      exp.completedJobs = (exp.completedJobs || 0) + 1;
      experts[expIndex] = exp;
      writeJsonFile(EXPERTS_FILE, experts);
    }
  }

  res.json({ success: true, message: 'Review submitted successfully', booking });
});

// POST /api/payments/process (Simulate payment processing)
app.post('/api/payments/process', (req, res) => {
  const { amount, gateway, customerPhone, bookingData } = req.body;
  
  // Simulate processing delay/verification
  const txnId = `TXN-${(gateway || 'PAY').toUpperCase().substring(0, 4)}-${Math.floor(100000 + Math.random() * 900000)}`;

  setTimeout(() => {
    res.json({
      success: true,
      transactionId: txnId,
      status: 'PAID',
      amount: amount || 49,
      currency: 'INR',
      gateway: gateway || 'phonepe',
      timestamp: new Date().toISOString(),
      message: 'Payment received and verified successfully.'
    });
  }, 400);
});

// GET /api/stats (Platform metrics)
app.get('/api/stats', (req, res) => {
  const experts = readJsonFile(EXPERTS_FILE);
  const bookings = readJsonFile(BOOKINGS_FILE);
  res.json({
    success: true,
    totalExperts: experts.length + 8400,
    totalBookings: bookings.length + 12450,
    categoriesCount: 8,
    satisfactionRate: '98.6%'
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`NeedXpert Server running on http://0.0.0.0:${PORT}`);
});
